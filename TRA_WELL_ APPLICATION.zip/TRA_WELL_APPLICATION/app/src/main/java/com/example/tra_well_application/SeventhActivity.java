package com.example.tra_well_application;

import android.content.Intent;
import android.content.Intent;
import android.content.pm.LabeledIntent;
import android.provider.MediaStore;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

public class SeventhActivity extends AppCompatActivity {
    ImageView iv15,iv16,iv17,iv18,iv19,iv20;
    TextView tv25,tv26,tv27,tv28,tv29,tv30,tv31,tv32,tv33,tv34;
    Button b7;
    ConstraintLayout cl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seventh);
        b7 = findViewById(R.id.button11);
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i12 = new Intent(SeventhActivity.this,TenthActivity.class);
                startActivity(i12);
            }
        });
    }
}
