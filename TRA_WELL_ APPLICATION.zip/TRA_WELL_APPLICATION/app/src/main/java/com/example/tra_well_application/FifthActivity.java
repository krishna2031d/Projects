package com.example.tra_well_application;

import android.content.Intent;
import android.content.pm.LabeledIntent;
import android.provider.MediaStore;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

public class FifthActivity extends AppCompatActivity {
    ImageView iv1,iv2,iv3,iv4,iv5,iv6,iv7;
    TextView tv4,tv5,tv7,tv8,tv9,tv10,tv11,tv12,tv13,tv14;
    Button b5;
    ConstraintLayout cl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fifth);
        b5=findViewById(R.id.button9);
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i10=new Intent(FifthActivity.this,TenthActivity.class);
                startActivity(i10);
            }
        });




    }
}

