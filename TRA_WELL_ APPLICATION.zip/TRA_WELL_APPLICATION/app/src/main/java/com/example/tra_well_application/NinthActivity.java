package com.example.tra_well_application;

import android.content.Intent;
import android.content.Intent;
import android.content.pm.LabeledIntent;
import android.provider.MediaStore;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

public class NinthActivity extends AppCompatActivity {
    ImageView iv27, iv28, iv29, iv30, iv31, iv32;
    TextView tv45, tv46, tv47, tv48, tv49, tv50, tv51, tv52, tv53, tv54;
    Button b9;
    ConstraintLayout cl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ninth);
        b9 = findViewById(R.id.button13);
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i13 = new Intent(NinthActivity.this, TenthActivity.class);
                startActivity(i13);
            }
        });
    }
}

