package com.example.tra_well_application;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    EditText e1;
    EditText e2;
    EditText e3;
    Button b,b1;
    String username;
    String pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=findViewById(R.id.input1);
        e2=findViewById(R.id.input20);
        e3=findViewById(R.id.input3);
        b=findViewById(R.id.BUTTON);
        b1 = findViewById(R.id.button2);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                username=e1.getText().toString();
                pass=e2.getText().toString();
                FirebaseDatabase db=FirebaseDatabase.getInstance();
                DatabaseReference key=db.getReference(username);
                key.setValue(pass);
                Toast.makeText(MainActivity.this, "user registered", Toast.LENGTH_SHORT).show();
                Intent i=new Intent(MainActivity.this,ThirdActivity.class);
                startActivity(i);
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i2=new Intent(MainActivity.this,SecondActivity.class);
                startActivity(i2);
            }
        });
    }
}