package com.example.tra_well_application;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SecondActivity extends AppCompatActivity {
    EditText e4;
    EditText e5;
    EditText e6;
    EditText e7;
    Button b3;
    String username;
    String pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        e4=findViewById(R.id.input4);
        e5=findViewById(R.id.input5);
        e6=findViewById(R.id.input6);
        e7=findViewById(R.id.input7);
        b3=findViewById(R.id.button3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                username=e4.getText().toString();
                pass=e7.getText().toString();
                Toast.makeText(SecondActivity.this, username, Toast.LENGTH_SHORT).show();
                FirebaseDatabase db=FirebaseDatabase.getInstance();
                DatabaseReference key=db.getReference(username);


                key.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String value = snapshot.getValue(String.class);
                        if (value.equals(pass)) {
                            Toast.makeText(SecondActivity.this, "login success", Toast.LENGTH_SHORT).show();
                            Intent i3 = new Intent(SecondActivity.this, ThirdActivity.class);
                            startActivity(i3);
                        } else {
                            Toast.makeText(SecondActivity.this, "login failed", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });

    }
}