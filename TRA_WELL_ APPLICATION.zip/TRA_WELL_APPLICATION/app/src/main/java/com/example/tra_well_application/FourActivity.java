package com.example.tra_well_application;

import android.content.Intent;
import android.content.pm.LabeledIntent;
import android.provider.MediaStore;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class FourActivity extends AppCompatActivity {
    RadioButton r1,r2,r3,r4,r5;
    TextView t3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_four);
        r1=findViewById(R.id.input9);
        r2=findViewById(R.id.input10);
        r3=findViewById(R.id.input11);
        r4=findViewById(R.id.input12);
        r5=findViewById(R.id.input13);
        t3=findViewById(R.id.textView3);
        r1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                Intent i5=new Intent(FourActivity.this,FifthActivity.class);
                startActivity(i5);
            }
        });
        r2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                Intent i6=new Intent(FourActivity.this,SixthActivity.class);
                startActivity(i6);

            }
        });
        r3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                Intent i7=new Intent(FourActivity.this,SeventhActivity.class);
                startActivity(i7);

            }
        });
        r4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                Intent i8=new Intent(FourActivity.this,EighthActivity.class);
                startActivity(i8);

            }
        });
        r5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                Intent i9=new Intent(FourActivity.this,NinthActivity.class);
                startActivity(i9);

            }
        });

    }
}
